# -*- coding: utf-8 -*-
"""
Created on Sun Apr 07 12:01:08 2019

@author: anjalinath
"""

#importing necessary libraries
import os
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('classic')
%matplotlib inline


#changing work directory
os.chdir("/Users/anjalinath/Downloads/")
#Read from Clipboard as file is password protected

#Read Stock Prices
stock_prices_df  = pd.read_clipboard()
#converting Year to python DateTime object
stock_prices_df["Date"] = pd.to_datetime(stock_prices_df["Date"],format='%m/%d/%Y')
#renaming the columns to strip whitespaces and in-between-spaces for easier usage
stock_prices_df.columns = ["Date","Stock_A","Stock_B"]

#Read number of shares
no_shares_df = pd.read_clipboard()
#converting Year to python DateTime object
no_shares_df["Year"] = pd.to_datetime(no_shares_df["Year"],format='%Y')
#renaming the columns to strip whitespaces and in-between-spaces for easier usage
no_shares_df.columns = ["Year","nShares_Stock_A","nShares_Stock_B"]


#joining the two dataframes grouped by Year to calculate market cap
res = pd.merge(stock_prices_df.assign(grouper=stock_prices_df["Date"].dt.to_period('Y')),
               no_shares_df.assign(grouper=no_shares_df['Year'].dt.to_period('y')),
               how='left', on='grouper')

#calculating individual market caps
res ["Market_Cap_A"] = res.Stock_A * res.nShares_Stock_A
res ["Market_Cap_B"] = res.Stock_B * res.nShares_Stock_B

#setting the index of the dataframe to Date for plotting
res.set_index("Date",inplace = True)

#Exporting the results to a csv file.
res.to_csv("result_python_assignment_v04072019.csv")

#plotting the results
fig, ax = plt.subplots()
plt.xlabel('Time', fontsize=18)
plt.ylabel('Market Cap', fontsize=16)

#Plotting series over time in a single plot

ax.plot(res.Market_Cap_A, '-b', label='Company A')
ax.plot(res.Market_Cap_B, '-r', label='Company B')

#Expanding the Legend over the figure as per requirements
leg = ax.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3,
           ncol=2, mode = "expand", borderaxespad=0.)

#saving the figure
fig.savefig('MarketCap_over_time.png')

           
